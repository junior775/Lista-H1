﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace Aluno.Models
{
    public class Produto
    {
        [Required, MinLength(3)]
        public string Descricao { get; set; }

        [Required, Range(0.01, double.MaxValue, ErrorMessage = "Preço deve ser maior que zero")]
        public decimal Preco { get; set; }

        [Required, Range(0, int.MaxValue, ErrorMessage = "Estoque não pode ser negativo")]
        public int Estoque { get; set; }

        [Required]
        [CustomValidation(typeof(Produto), nameof(ValidarCodigoProduto))]
        public string CodigoProduto { get; set; }

        public static ValidationResult ValidarCodigoProduto(string codigo, ValidationContext context)
        {
            if (Regex.IsMatch(codigo, @"^[A-Z]{3}-\d{4}$"))
                return ValidationResult.Success;

            return new ValidationResult("Código inválido. Formato esperado: AAA-1234.");
        }
    }
}
