﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions; // Ensure Regex is imported

namespace Aluno.Models
{
    public class Aluno // Corrected class name from "Class" to "Aluno"
    {
        [Required, MinLength(3)]
        public string Nome { get; set; }

        [Required]
        [CustomValidation(typeof(Aluno), nameof(ValidarRa))] // Now references the correct class name
        public string Ra { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        [Required, RegularExpression(@"^\d{11}$", ErrorMessage = "CPF inválido")]
        public string Cpf { get; set; }

        public bool Ativo { get; set; }

        public static ValidationResult ValidarRa(string ra, ValidationContext context)
        {
            if (Regex.IsMatch(ra, @"^RA\d{6}$"))
                return ValidationResult.Success;

            return new ValidationResult("RA inválido. Deve começar com 'RA' seguido de 6 dígitos numéricos.");
        }
    }
}
