﻿using Aluno.Models;
using Microsoft.AspNetCore.Mvc;

namespace Aluno.Contrllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProdutoController : ControllerBase
    {
        [HttpPost]
        public IActionResult CriarProduto([FromBody] Produto produto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            return Ok(new { mensagem = "Produto cadastrado com sucesso!", dados = produto });
        }
    }
}