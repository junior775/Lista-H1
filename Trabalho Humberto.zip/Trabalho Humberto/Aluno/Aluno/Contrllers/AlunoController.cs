﻿using Microsoft.AspNetCore.Mvc;

namespace Aluno.Contrllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AlunoController : ControllerBase
    {
        [HttpPost]
        public IActionResult CriarAluno([FromBody] AlunoController aluno)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            return Ok(new { mensagem = "Aluno cadastrado com sucesso!", dados = aluno });
        }
    }
}
